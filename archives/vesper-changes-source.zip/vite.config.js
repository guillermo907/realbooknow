import { defineConfig } from 'vite';
export default defineConfig({ optimizeDeps: { entries: ['index.html'] }, build: { target: 'es2022', chunkSizeWarningLimit: 220 }, server: { strictPort: true } });
